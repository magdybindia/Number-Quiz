package ucl.numberquizz;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
//import android.widget.EditText;
import android.widget.TextView;

public class LevelTwoQst extends Activity {
    // Initializing variables
    // EditText inputName;
    //EditText inputEmail;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.leveltwoqst_two);

        TextView txtName = (TextView) findViewById(R.id.textLevel2);
        Button btnClose = (Button) findViewById(R.id.btnClose);
        Button btnnext = (Button)findViewById(R.id.btnLevelTwo);
        Button btnscore = (Button)findViewById(R.id.btnScoreLevelTwo);

        Intent i = getIntent();

        txtName.setText("");

        int n1 = (int) ((Math.random() + 1) * 6) * 5;
        int n2 = (int) ((Math.random() + 1) * 6) * 5;
        int n3 = (int) ((Math.random() + 1) * 6) * 5;
        // convert from int to string
        String name = "" + n1 + "-" + n2 + "-" + n3 + "";
        // display string
        txtName.setText(name);
        //Receive the user response
        String UserAnswer = i.getStringExtra("btnScoreLevelTwo");

        //Convert from String to Int
        try {
            // the String to int conversion happens here
            int result = Integer.parseInt(UserAnswer);

        } catch (NumberFormatException nfe) {
            System.out.println("NumberFormatException: " + nfe.getMessage());
        }
        // Binding Click event to Button
        btnClose.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Closing SecondScreen Activity
                finish();
            }
        });

        // Listening to Score button
        btnscore.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), ScoreBoard.class);

                startActivity(nextScreen);

            }
        });
    }
}