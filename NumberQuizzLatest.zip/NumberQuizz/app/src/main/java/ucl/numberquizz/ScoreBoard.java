package ucl.numberquizz;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//import android.widget.EditText;

public class ScoreBoard extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.scoreboard);

        Button btnRepeatLevel = (Button) findViewById(R.id.RepeatLevel);
        Button btnMainMenu = (Button) findViewById(R.id.MainMenu);
/*
        btnRepeatLevel.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent

                Intent nextScreen = new Intent(getApplicationContext(), LevelScreenActivity.class);

                startActivity(nextScreen);
                //finish();

            }
        });


        btnMainMenu.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), MainscreenActivity.class);


                startActivity(nextScreen);
                //finish();

            }
        });
*/
    }


    public void onButtonClick(View v) {

        Button btnRepeatLevel = (Button) findViewById(R.id.RepeatLevel);
        Button btnMainMenu = (Button) findViewById(R.id.MainMenu);

        btnRepeatLevel.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelScreenActivity.class);

                startActivity(nextScreen);
                //finish();

            }
        });

        btnMainMenu.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), MainscreenActivity.class);

                startActivity(nextScreen);
                //finish();

            }
        });
    }


}