package ucl.numberquizz;

/**
 * Created by Bindia Venugopal on 19/03/2016.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LevelScreenActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.levelscreen_activity);
        Button btnNextSrnOne = (Button) findViewById(R.id.btnOne);
        Button btnNextSrnTwo = (Button) findViewById(R.id.btnTwo);
        Button btnNextSrnThree = (Button) findViewById(R.id.btnThree);
        Button btnNextSrnFour = (Button) findViewById(R.id.btnFour);
        Button btnNextSrnMixitup = (Button) findViewById(R.id.btnmixitup);
        Button btnNextSrnClose = (Button) findViewById(R.id.btnClose);

        btnNextSrnOne.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelOneQstOne.class);

                startActivity(nextScreen);

            }
        });

        btnNextSrnTwo.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelTwoQst.class);
                startActivity(nextScreen);

            }
        });

        btnNextSrnThree.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelThreeQst.class);

                startActivity(nextScreen);

            }
        });

        btnNextSrnFour.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelFourQst.class);


                startActivity(nextScreen);

            }
        });

        btnNextSrnMixitup.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelMultiQst.class);

                startActivity(nextScreen);

            }
        });

        btnNextSrnClose.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), MainscreenActivity.class);

                startActivity(nextScreen);


            }
        });

    }

/*
    public void onButtonClick(View v) {

        Button btnNextSrnOne = (Button) findViewById(R.id.btnOne);
        Button btnNextSrnTwo = (Button) findViewById(R.id.btnTwo);
        Button btnNextSrnThree = (Button) findViewById(R.id.btnThree);
        Button btnNextSrnFour = (Button) findViewById(R.id.btnFour);
        Button btnNextSrnMixitup = (Button) findViewById(R.id.btnmixitup);
        Button btnNextSrnClose = (Button) findViewById(R.id.btnClose);

        btnNextSrnOne.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelOneQstOne.class);

                startActivity(nextScreen);

            }
        });

        btnNextSrnTwo.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelTwoQst.class);
                startActivity(nextScreen);

            }
        });

        btnNextSrnThree.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelThreeQst.class);

                startActivity(nextScreen);

            }
        });

        btnNextSrnFour.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelFourQst.class);


                startActivity(nextScreen);

            }
        });

        btnNextSrnMixitup.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), LevelMultiQst.class);

                startActivity(nextScreen);

            }
        });

        btnNextSrnClose.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Starting a new Intent
                Intent nextScreen = new Intent(getApplicationContext(), MainscreenActivity.class);

                startActivity(nextScreen);


            }
        });

    }
*/
}
