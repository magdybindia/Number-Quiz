package ucl.numberquizz;



import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//import android.widget.EditText;

public class LevelFourQst extends Activity {
    // Initializing variables
    // EditText inputName;
    //EditText inputEmail;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.levelfourqst_four);



        //inputName = (EditText) findViewById(R.id.name);
        //inputEmail = (EditText) findViewById(R.id.email);
        Button btnClose = (Button) findViewById(R.id.btnClose);

        // Intent i = getIntent();
        // Receiving the Data
        // String name = i.getStringExtra("name");
        //String email = i.getStringExtra("email");
        //Log.e("Second Screen", name + "." + email);

        // Displaying Received data
        //txtName.setText(name);
        //txtEmail.setText(email);

        // Binding Click event to Button
        btnClose.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Closing SecondScreen Activity
                finish();
            }
        });
    }
}
