package ucl.numberquizz;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
//import android.widget.EditText;
import android.widget.TextView;


public class LevelOneQstOne extends Activity {
    // Initializing variables
    // EditText inputName;
    //EditText inputEmail;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leveloneqst_one);


        //inputName = (EditText) findViewById(R.id.name);
        //inputEmail = (EditText) findViewById(R.id.email);
        TextView txtName = (TextView) findViewById(R.id.Level1Text);
        Button btnClose = (Button) findViewById(R.id.btnClose);
        Button btnnext = (Button)findViewById(R.id.btnnext);

        Intent i = getIntent();

        txtName.setText("");

        int n1 = (int) ((Math.random() + 1) * 6) * 5;
        int n2 = (int) ((Math.random() + 1) * 6) * 5;
        int n3 = (int) ((Math.random() + 1) * 6) * 5;
        // convert from int to string
        String name = "" + n1 + "+" + n2 + "+" + n3 + "";
        // display string
        txtName.setText(name);
        //Receive the user response
        String UserAnswer = i.getStringExtra("Level1UserAnswer");

        //Convert from String to Int
        try {
            // the String to int conversion happens here
            int result = Integer.parseInt(UserAnswer);

        } catch (NumberFormatException nfe) {
            System.out.println("NumberFormatException: " + nfe.getMessage());
        }

        // Binding Click event to Button
        btnClose.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {
                //Closing SecondScreen Activity
                finish();
            }
        });
    }

// Next Button

    public void OnNextButton(View v) {

        TextView txtName = (TextView) findViewById(R.id.Level1Text);
        TextView LevelTxt = (TextView) findViewById(R.id.Level1UserAnswer);
        Intent i = getIntent();

        txtName.setText("");
        LevelTxt.setText("");

        int n1 = (int) ((Math.random() + 1) * 6) * 5;
        int n2 = (int) ((Math.random() + 1) * 6) * 5;
        int n3 = (int) ((Math.random() + 1) * 6) * 5;

        // convert from int to string
        String name = "" + n1 + "+" + n2 + "+" + n3 + "";
        // display string
        txtName.setText(name);
        //Create an intent

        //Receive the user response
        String UserAnswer = i.getStringExtra("Level1UserAnswer");
        //Convert from String to Int
        try {
            // the String to int conversion happens here
            int result[i++] = Integer.parseInt(UserAnswer);
        } catch (NumberFormatException nfe) {
            System.out.println("NumberFormatException: " + nfe.getMessage());
        }
    }


    // Score Button


    public void OnScoreButton(View v) {

        //Starting a new Intent
        Intent nextScreen = new Intent(getApplicationContext(), ScoreBoard.class);
        //Sending data to another Activity
        //  nextScreen.putExtra("name", inputName.getText().toString());
        // nextScreen.putExtra("email", inputEmail.getText().toString());

        // Log.e("n", inputName.getText()+"."+ inputEmail.getText());
//finish();
        startActivity(nextScreen);
        //finish();
    }

}
